SF2 Player Android v0.3. Experimental build with SF2 playback, preset selection, volume, octave/transposition, sustain, and basic USB MIDI input. Build via GitHub Actions workflow.
