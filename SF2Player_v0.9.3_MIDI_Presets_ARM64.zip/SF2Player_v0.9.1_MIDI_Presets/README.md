# SF2 Player v0.9.1 — MIDI CC salvos nos presets

Esta versão inclui os mapeamentos MIDI CC no JSON de cada preset. Ao salvar um preset, são armazenados CC master, sustain e volumes das faixas 1 a 5. Ao carregar, os mapeamentos são restaurados. Presets antigos sem esses campos continuam compatíveis e usam os valores padrão.

Projeto experimental: compile com o workflow fornecido e teste em dispositivo Android real. A compilação e o funcionamento do FluidSynth não foram verificados neste ambiente.
