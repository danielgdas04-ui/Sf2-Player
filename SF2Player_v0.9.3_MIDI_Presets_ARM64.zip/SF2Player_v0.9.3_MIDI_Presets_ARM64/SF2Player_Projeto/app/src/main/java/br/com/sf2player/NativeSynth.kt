package br.com.sf2player

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.pow

class NativeSynth {
    companion object { init { System.loadLibrary("sf2native") } }
    private external fun loadNative(path: String, rate: Int): Boolean
    private external fun noteOnNative(channel: Int, key: Int, velocity: Int)
    private external fun noteOffNative(channel: Int, key: Int)
    private external fun volumeNative(volume: Float)
    private external fun trackVolumeNative(channel: Int, volume: Float)
    private external fun renderNative(buffer: ShortArray, frames: Int)
    private external fun closeNative()
    private external fun presetCountNative(): Int
    private external fun presetNameNative(index: Int): String
    private external fun selectPresetNative(channel: Int, index: Int): Boolean
    private external fun sustainNative(channel: Int, enabled: Boolean)
    private external fun setEffectsNative(reverb: Boolean, reverbLevel: Float, chorus: Boolean, chorusLevel: Float)

    private var track: AudioTrack? = null
    private val running = AtomicBoolean(false)
    private val noteStateLock = Any()
    private val sustainDown = BooleanArray(16)
    private val deferredNoteOff = Array(16) { mutableSetOf<Int>() }
    @Volatile private var sampleRate = 48000
    @Volatile private var bufferFrames = 256
    @Volatile var velocityCurve = 1.0f
    @Volatile var loaded = false; private set
    @Volatile var status = "Selecione um SoundFont"; private set

    fun load(file: File, rate: Int = 48000): Boolean {
        stopAudio(); sampleRate = rate
        loaded = loadNative(file.absolutePath, rate)
        status = if (loaded) "FluidSynth carregado" else "Não foi possível ler este SF2"
        if (loaded) {
            synchronized(noteStateLock) { for (ch in 0 until 16) { sustainDown[ch] = false; deferredNoteOff[ch].clear() } }
            setVolume(0.8f)
            for (ch in 0 until 5) { selectPreset(0, ch); setTrackVolume(ch, 1f) }
            startAudio()
        }
        return loaded
    }
    fun presetCount() = if (loaded) presetCountNative().coerceAtLeast(0) else 0
    fun presetName(index: Int) = if (loaded && index in 0 until presetCount()) presetNameNative(index) else "Instrumento ${index + 1}"
    fun selectPreset(index: Int, channel: Int = 0) = loaded && channel in 0..15 && selectPresetNative(channel, index)
    fun setSustain(enabled: Boolean, channel: Int = 0) {
        if (!loaded) return
        val ch=channel.coerceIn(0,15)
        synchronized(noteStateLock) {
            if (sustainDown[ch] == enabled) return
            sustainDown[ch]=enabled
            sustainNative(ch, enabled)
            if (!enabled) { deferredNoteOff[ch].forEach { noteOffNative(ch,it) }; deferredNoteOff[ch].clear() }
        }
    }
    fun setBufferFrames(frames: Int) { val f=frames.coerceIn(128,1024); if(bufferFrames==f)return; bufferFrames=f; if(loaded){stopAudio();startAudio()} }
    fun getBufferFrames()=bufferFrames
    fun setEffects(reverb: Boolean, reverbLevel: Float, chorus: Boolean, chorusLevel: Float) { setEffectsNative(reverb,reverbLevel,chorus,chorusLevel) }
    private fun startAudio() {
        val min=AudioTrack.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(bufferFrames*4)
        val size=maxOf(min,bufferFrames*4*2)
        val t=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(size).setTransferMode(AudioTrack.MODE_STREAM).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()
        track=t; running.set(true); t.play()
        Thread({ val frames=bufferFrames; val buf=ShortArray(frames*2); while(running.get()) { renderNative(buf,frames); var offset=0; while(offset<buf.size&&running.get()){val wrote=t.write(buf,offset,buf.size-offset,AudioTrack.WRITE_BLOCKING);if(wrote<0)break;if(wrote==0)Thread.yield()else offset+=wrote} } },"FluidSynth-Audio").apply{priority=Thread.MAX_PRIORITY;start()}
    }
    fun noteOn(key:Int,velocity:Int=100,channel:Int=0){if(!loaded)return;val ch=channel.coerceIn(0,15);val k=key.coerceIn(0,127);val v=(velocity.coerceIn(1,127)/127.0).pow(velocityCurve.coerceIn(0.5f,2.0f).toDouble());synchronized(noteStateLock){deferredNoteOff[ch].remove(k);noteOnNative(ch,k,(v*127.0).toInt().coerceIn(1,127))}}
    fun noteOff(key:Int,channel:Int=0){if(!loaded)return;val ch=channel.coerceIn(0,15);val k=key.coerceIn(0,127);synchronized(noteStateLock){if(sustainDown[ch])deferredNoteOff[ch].add(k)else noteOffNative(ch,k)}}
    fun setVolume(v:Float){volumeNative(v.coerceIn(0f,1f))}
    fun setTrackVolume(channel:Int,v:Float){if(loaded)trackVolumeNative(channel.coerceIn(0,15),v.coerceIn(0f,1f))}
    fun stopAudio(){running.set(false);try{track?.pause();track?.flush();track?.stop();track?.release()}catch(_:Exception){};track=null}
    fun close(){stopAudio();closeNative();loaded=false}
}
