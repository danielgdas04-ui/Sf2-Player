\
#include <jni.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <pthread.h>
#include <fluidsynth.h>

static fluid_settings_t *settings = NULL;
static fluid_synth_t *synth = NULL;
static int sfid = -1;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static float master_gain = 0.8f;
static float reverb_level = 0.35f;
static float chorus_level = 0.25f;
static int reverb_enabled = 1, chorus_enabled = 1;
static int preset_bank[512], preset_num[512], preset_count = 0;
static char preset_names[512][160];

static void refresh_presets(void) {
    preset_count = 0;
    if (!synth || sfid < 0) return;
    fluid_sfont_t *sf = fluid_synth_get_sfont_by_id(synth, sfid);
    if (!sf) return;
    fluid_sfont_iteration_start(sf);
    fluid_preset_t *pr;
    while ((pr = fluid_sfont_iteration_next(sf)) != NULL && preset_count < 512) {
        int i = preset_count++;
        preset_bank[i] = fluid_preset_get_banknum(pr);
        preset_num[i] = fluid_preset_get_num(pr);
        const char *name = fluid_preset_get_name(pr);
        snprintf(preset_names[i], sizeof(preset_names[i]), "%s", name ? name : "Instrument");
    }
}

JNIEXPORT jboolean JNICALL Java_br_com_sf2player_NativeSynth_loadNative(JNIEnv *env, jobject thiz, jstring path, jint rate) {
    const char *p = (*env)->GetStringUTFChars(env, path, 0);
    if (!p) return JNI_FALSE;
    pthread_mutex_lock(&lock);
    if (synth) { delete_fluid_synth(synth); synth = NULL; }
    if (settings) { delete_fluid_settings(settings); settings = NULL; }
    settings = new_fluid_settings();
    if (settings) {
        fluid_settings_setnum(settings, "synth.sample-rate", (double)rate);
        fluid_settings_setnum(settings, "synth.gain", 0.8);
        fluid_settings_setint(settings, "synth.polyphony", 256);
        fluid_settings_setint(settings, "synth.reverb.active", reverb_enabled);
        fluid_settings_setint(settings, "synth.chorus.active", chorus_enabled);
        synth = new_fluid_synth(settings);
    }
    if (synth) {
        sfid = fluid_synth_sfload(synth, p, 1);
        if (sfid < 0) { delete_fluid_synth(synth); synth = NULL; }
        else {
            fluid_synth_set_gain(synth, master_gain);
            fluid_synth_set_reverb(synth, 0.45, 0.25, 0.8, reverb_level);
            fluid_synth_set_chorus(synth, 3, chorus_level, 0.25, 8.0, FLUID_CHORUS_MOD_SINE);
            refresh_presets();
            for (int ch = 0; ch < 5; ch++) {
                if (preset_count > 0) fluid_synth_program_select(synth, ch, sfid, preset_bank[ch < preset_count ? ch : 0], preset_num[ch < preset_count ? ch : 0]);
                fluid_synth_cc(synth, ch, 7, 127);
            }
        }
    }
    jboolean ok = synth ? JNI_TRUE : JNI_FALSE;
    pthread_mutex_unlock(&lock);
    (*env)->ReleaseStringUTFChars(env, path, p);
    return ok;
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_noteOnNative(JNIEnv *e, jobject o, jint ch, jint key, jint vel) {
    pthread_mutex_lock(&lock); if (synth) fluid_synth_noteon(synth, ch, key, vel); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_noteOffNative(JNIEnv *e, jobject o, jint ch, jint key) {
    pthread_mutex_lock(&lock); if (synth) fluid_synth_noteoff(synth, ch, key); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_volumeNative(JNIEnv *e, jobject o, jfloat v) {
    pthread_mutex_lock(&lock); master_gain = fmaxf(0.0f, fminf(2.0f, v)); if (synth) fluid_synth_set_gain(synth, master_gain); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_trackVolumeNative(JNIEnv *e, jobject o, jint ch, jfloat v) {
    pthread_mutex_lock(&lock); if (synth) fluid_synth_cc(synth, ch, 7, (int)(fmaxf(0.f, fminf(1.f, v))*127.f)); pthread_mutex_unlock(&lock);
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_renderNative(JNIEnv *e, jobject o, jshortArray arr, jint frames) {
    jsize n = (*e)->GetArrayLength(e, arr); if (n < frames*2) return;
    jshort *out = (*e)->GetShortArrayElements(e, arr, NULL);
    float *left = (float*)malloc(sizeof(float)*frames), *right=(float*)malloc(sizeof(float)*frames);
    if (!left || !right) { if(left) free(left); if(right) free(right); (*e)->ReleaseShortArrayElements(e, arr, out, 0); return; }
    pthread_mutex_lock(&lock);
    if (synth && fluid_synth_write_float(synth, frames, left, 0, 1, right, 0, 1) == FLUID_OK) {
        for (int i=0;i<frames;i++) { float l=left[i], r=right[i]; if(l>1.f)l=1.f;if(l< -1.f)l=-1.f;if(r>1.f)r=1.f;if(r< -1.f)r=-1.f;out[i*2]=(jshort)(l*32767.f);out[i*2+1]=(jshort)(r*32767.f); }
    } else for(int i=0;i<frames*2;i++) out[i]=0;
    pthread_mutex_unlock(&lock); free(left); free(right); (*e)->ReleaseShortArrayElements(e, arr, out, 0);
}
JNIEXPORT jint JNICALL Java_br_com_sf2player_NativeSynth_presetCountNative(JNIEnv *e,jobject o){pthread_mutex_lock(&lock);int n=preset_count;pthread_mutex_unlock(&lock);return n;}
JNIEXPORT jstring JNICALL Java_br_com_sf2player_NativeSynth_presetNameNative(JNIEnv *e,jobject o,jint i){pthread_mutex_lock(&lock);const char *n=(i>=0&&i<preset_count)?preset_names[i]:"Instrumento";jstring r=(*e)->NewStringUTF(e,n);pthread_mutex_unlock(&lock);return r;}
JNIEXPORT jboolean JNICALL Java_br_com_sf2player_NativeSynth_selectPresetNative(JNIEnv *e,jobject o,jint ch,jint i){pthread_mutex_lock(&lock);int ok=(synth&&ch>=0&&ch<16&&i>=0&&i<preset_count)?(fluid_synth_program_select(synth,ch,sfid,preset_bank[i],preset_num[i])==FLUID_OK):0;pthread_mutex_unlock(&lock);return ok?JNI_TRUE:JNI_FALSE;}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_sustainNative(JNIEnv *e,jobject o,jint ch,jboolean enabled){pthread_mutex_lock(&lock);if(synth)fluid_synth_cc(synth,ch,64,enabled?127:0);pthread_mutex_unlock(&lock);}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_setEffectsNative(JNIEnv *e,jobject o,jboolean rev,jfloat rv,jboolean cho,jfloat cv){pthread_mutex_lock(&lock);reverb_enabled=rev?1:0;chorus_enabled=cho?1:0;reverb_level=fmaxf(0.f,fminf(1.f,rv));chorus_level=fmaxf(0.f,fminf(10.f,cv));if(settings){fluid_settings_setint(settings,"synth.reverb.active",reverb_enabled);fluid_settings_setint(settings,"synth.chorus.active",chorus_enabled);}if(synth){fluid_synth_set_reverb(synth,0.45,0.25,0.8,reverb_level);fluid_synth_set_chorus(synth,3,chorus_level,0.25,8.0,FLUID_CHORUS_MOD_SINE);if(!reverb_enabled)fluid_synth_set_reverb(synth,0.45,0.25,0.8,0.0);if(!chorus_enabled)fluid_synth_set_chorus(synth,3,0.0,0.25,8.0,FLUID_CHORUS_MOD_SINE);}pthread_mutex_unlock(&lock);}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_closeNative(JNIEnv *e,jobject o){pthread_mutex_lock(&lock);if(synth){delete_fluid_synth(synth);synth=NULL;}if(settings){delete_fluid_settings(settings);settings=NULL;}sfid=-1;preset_count=0;pthread_mutex_unlock(&lock);}
