# SF2 Player v0.8 — FluidSynth experimental

This experimental branch replaces TinySoundFont with FluidSynth. It adds adjustable AudioTrack buffer (128/256/512/1024 frames), velocity curve, reverb and chorus.

The workflow builds FluidSynth native libraries for Android and packages the library/header with the app. This version is experimental and has not been verified on a physical device; run GitHub Actions and test SF2 loading, sound, MIDI, sustain, presets, effects and buffer changes before using it live.

FluidSynth is licensed under LGPL-2.1-or-later; preserve its license and notices in redistributed builds.
