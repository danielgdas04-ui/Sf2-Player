package br.com.sf2player

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.pow

class NativeSynth {
    companion object { init { System.loadLibrary("sf2native") } }

    // Returns FluidSynth's internal SoundFont ID, or -1 on failure.
    private external fun loadNative(path: String, rate: Int): Int
    private external fun noteOnNative(channel: Int, key: Int, velocity: Int)
    private external fun noteOffNative(channel: Int, key: Int)
    private external fun volumeNative(volume: Float)
    private external fun trackVolumeNative(channel: Int, volume: Float)
    private external fun renderNative(buffer: ShortArray, frames: Int)
    private external fun closeNative()
    private external fun presetCountNative(soundFontNativeId: Int): Int
    private external fun presetNameNative(soundFontNativeId: Int, index: Int): String
    private external fun selectPresetNative(channel: Int, soundFontNativeId: Int, index: Int): Boolean
    private external fun sustainNative(channel: Int, enabled: Boolean)
    private external fun setEffectsNative(reverb: Boolean, reverbLevel: Float, chorus: Boolean, chorusLevel: Float)

    private var audioTrack: AudioTrack? = null
    private val running = AtomicBoolean(false)
    private val audioLifecycleLock = Any()
    @Volatile private var audioThread: Thread? = null
    private val noteStateLock = Any()
    private val sustainDown = BooleanArray(16)
    private val deferredNoteOff = Array(16) { mutableSetOf<Int>() }
    @Volatile private var sampleRate = 48000
    @Volatile private var bufferFrames = 256
    @Volatile var velocityCurve = 1.0f
    @Volatile var loaded = false; private set
    @Volatile var status = "Importe um SoundFont"; private set

    /** Adds a SoundFont to the existing synth; does not remove previously imported fonts. */
    @Synchronized
    fun loadSoundFont(file: File, rate: Int = 48000): Int {
        if (!file.isFile || file.length() <= 0L) {
            status = "Arquivo SoundFont inválido"
            return -1
        }
        val wasLoaded = loaded
        sampleRate = rate
        val id = loadNative(file.absolutePath, rate)
        if (id < 0) {
            status = "Não foi possível ler ${file.name}"
            return -1
        }
        loaded = true
        status = "SoundFont carregado: ${file.name}"
        if (!wasLoaded) {
            synchronized(noteStateLock) {
                for (ch in 0 until 16) {
                    sustainDown[ch] = false
                    deferredNoteOff[ch].clear()
                }
            }
            setVolume(0.8f)
            startAudio()
        }
        return id
    }

    // Compatibility wrapper for older call sites.
    fun load(file: File, rate: Int = 48000): Boolean = loadSoundFont(file, rate) >= 0

    fun presetCount(soundFontNativeId: Int): Int =
        if (loaded && soundFontNativeId >= 0) presetCountNative(soundFontNativeId).coerceAtLeast(0) else 0

    fun presetName(index: Int, soundFontNativeId: Int): String =
        if (loaded && index in 0 until presetCount(soundFontNativeId)) presetNameNative(soundFontNativeId, index)
        else "Instrumento ${index + 1}"

    fun selectPreset(index: Int, channel: Int = 0, soundFontNativeId: Int): Boolean =
        loaded && channel in 0..15 && soundFontNativeId >= 0 &&
            selectPresetNative(channel, soundFontNativeId, index)

    fun setSustain(enabled: Boolean, channel: Int = 0) {
        if (!loaded) return
        val ch = channel.coerceIn(0, 15)
        synchronized(noteStateLock) {
            if (sustainDown[ch] == enabled) return
            sustainDown[ch] = enabled
            sustainNative(ch, enabled)
            if (!enabled) {
                deferredNoteOff[ch].forEach { noteOffNative(ch, it) }
                deferredNoteOff[ch].clear()
            }
        }
    }

    @Synchronized
    fun setBufferFrames(frames: Int) {
        val f = frames.coerceIn(128, 1024)
        if (bufferFrames == f) return
        bufferFrames = f
        if (loaded) {
            stopAudio()
            startAudio()
        }
    }

    fun getBufferFrames() = bufferFrames
    fun setEffects(reverb: Boolean, reverbLevel: Float, chorus: Boolean, chorusLevel: Float) =
        setEffectsNative(reverb, reverbLevel, chorus, chorusLevel)

    private fun startAudio() = synchronized(audioLifecycleLock) {
        if (!loaded || running.get() || audioThread?.isAlive == true) return@synchronized

        val frames = bufferFrames
        val minBytes = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBytes <= 0) {
            status = "Formato de áudio não suportado pelo dispositivo"
            return@synchronized
        }

        val size = maxOf(minBytes, frames * 8)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
                )
                .setBufferSizeInBytes(size)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (e: Exception) {
            status = "Falha ao iniciar áudio: ${e.message ?: "erro desconhecido"}"
            return@synchronized
        }

        if (track.state != AudioTrack.STATE_INITIALIZED) {
            try { track.release() } catch (_: Exception) {}
            status = "Não foi possível inicializar a saída de áudio"
            return@synchronized
        }

        audioTrack = track
        running.set(true)
        try {
            track.play()
        } catch (e: Exception) {
            running.set(false)
            audioTrack = null
            try { track.release() } catch (_: Exception) {}
            status = "Falha ao iniciar reprodução: ${e.message ?: "erro desconhecido"}"
            return@synchronized
        }

        val worker = Thread({
            val buffer = ShortArray(frames * 2)
            try {
                while (running.get() && !Thread.currentThread().isInterrupted) {
                    renderNative(buffer, frames)
                    var offset = 0
                    while (offset < buffer.size && running.get()) {
                        val wrote = try {
                            track.write(buffer, offset, buffer.size - offset, AudioTrack.WRITE_BLOCKING)
                        } catch (_: IllegalStateException) { break }
                        if (wrote < 0) break
                        if (wrote == 0) Thread.yield() else offset += wrote
                    }
                }
            } catch (_: Exception) {
                // An audio-device transition must not crash the application.
            } finally {
                running.set(false)
            }
        }, "FluidSynth-Audio")
        worker.priority = Thread.MAX_PRIORITY
        audioThread = worker
        worker.start()
    }

    fun noteOn(key: Int, velocity: Int = 100, channel: Int = 0) {
        if (!loaded) return
        val ch = channel.coerceIn(0, 15)
        val k = key.coerceIn(0, 127)
        val v = (velocity.coerceIn(1, 127) / 127.0)
            .pow(velocityCurve.coerceIn(0.5f, 2.0f).toDouble())
        synchronized(noteStateLock) {
            deferredNoteOff[ch].remove(k)
            noteOnNative(ch, k, (v * 127.0).toInt().coerceIn(1, 127))
        }
    }

    fun noteOff(key: Int, channel: Int = 0) {
        if (!loaded) return
        val ch = channel.coerceIn(0, 15)
        val k = key.coerceIn(0, 127)
        synchronized(noteStateLock) {
            if (sustainDown[ch]) deferredNoteOff[ch].add(k) else noteOffNative(ch, k)
        }
    }

    fun setVolume(v: Float) = volumeNative(v.coerceIn(0f, 1f))
    fun setTrackVolume(channel: Int, v: Float) {
        if (loaded) trackVolumeNative(channel.coerceIn(0, 15), v.coerceIn(0f, 1f))
    }

    fun stopAudio() {
        val track: AudioTrack?
        val worker: Thread?
        synchronized(audioLifecycleLock) {
            running.set(false)
            track = audioTrack
            worker = audioThread
            audioTrack = null
            // Keep the worker reference until it exits so a second renderer cannot start over it.
            // stop() normally unblocks a blocking write; release only after the worker exits.
            try { track?.pause() } catch (_: Exception) {}
            try { track?.flush() } catch (_: Exception) {}
            try { track?.stop() } catch (_: Exception) {}
            worker?.interrupt()
        }

        if (worker != null && worker !== Thread.currentThread()) {
            try { worker.join(750) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            if (worker.isAlive) {
                // AudioTrack.stop() should unblock WRITE_BLOCKING; give the thread a final chance.
                try { worker.join(750) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            }
        }
        try { track?.release() } catch (_: Exception) {}
        synchronized(audioLifecycleLock) {
            if (audioThread === worker && (worker == null || !worker.isAlive)) audioThread = null
        }
    }

    @Synchronized
    fun close() {
        stopAudio()
        synchronized(noteStateLock) {
            for (ch in 0 until 16) {
                sustainDown[ch] = false
                deferredNoteOff[ch].clear()
            }
        }
        closeNative()
        loaded = false
    }
}
