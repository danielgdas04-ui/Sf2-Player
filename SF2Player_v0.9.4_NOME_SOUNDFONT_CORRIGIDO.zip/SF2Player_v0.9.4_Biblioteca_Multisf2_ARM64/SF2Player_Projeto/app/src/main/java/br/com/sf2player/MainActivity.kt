package br.com.sf2player

import android.content.Context
import android.content.res.Configuration
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

private val bg = Color(0xFF0D1117)
private val panel = Color(0xFF171F2B)
private val cyan = Color(0xFF38BDF8)
private val white = Color(0xFFF8FAFC)
private val muted = Color(0xFF9CA3AF)

private data class SoundFontItem(val id: String, val name: String, val file: File, val nativeId: Int)

private data class TrackState(
    val name: String,
    val soundFontId: String = "",
    val presetIndex: Int = 0,
    val volume: Float = 0.8f,
    val enabled: Boolean = true
)

private data class SavedPreset(val name: String, val json: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 17, 23)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = bg, surface = panel, onBackground = white, onSurface = white)) {
                PlayerScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { NativeSynth() }

    var sf2Name by remember { mutableStateOf("Biblioteca vazia") }
    var library by remember { mutableStateOf<List<SoundFontItem>>(emptyList()) }
    val libraryDir = remember { File(context.filesDir, "soundfonts").apply { mkdirs() } }
    var status by remember { mutableStateOf("Escolha um arquivo .sf2 para começar") }
    var loaded by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(0.8f) }
    var octave by remember { mutableIntStateOf(0) }
    var transpose by remember { mutableIntStateOf(0) }
    var sustain by remember { mutableStateOf(false) }
    var bufferFrames by remember { mutableIntStateOf(256) }
    var velocityCurve by remember { mutableFloatStateOf(1.0f) }
    var reverbEnabled by remember { mutableStateOf(true) }
    var reverbLevel by remember { mutableFloatStateOf(0.35f) }
    var chorusEnabled by remember { mutableStateOf(true) }
    var chorusLevel by remember { mutableFloatStateOf(0.25f) }
    var tab by remember { mutableStateOf("Tocar") }
    var midiStatus by remember { mutableStateOf("MIDI USB: desconectado") }
    val midiDevices = remember { mutableStateListOf<MidiDevice>() }
    val midiNames = remember { mutableStateListOf<String>() }
    var midiAvailable by remember { mutableStateOf<List<MidiDeviceInfo>>(emptyList()) }
    var ccMaster by remember { mutableStateOf("7") }
    var ccSustain by remember { mutableStateOf("64") }
    var ccTrack1 by remember { mutableStateOf("20") }
    var ccTrack2 by remember { mutableStateOf("21") }
    var ccTrack3 by remember { mutableStateOf("22") }
    var ccTrack4 by remember { mutableStateOf("23") }
    var ccTrack5 by remember { mutableStateOf("24") }
    var tracks by remember { mutableStateOf(List(5) { i -> TrackState("Faixa ${i + 1}", volume = 0.8f, enabled = i == 0) }) }
    var newPresetName by remember { mutableStateOf("") }
    var savedPresets by remember { mutableStateOf(readSavedPresets(context)) }
    var presetMessage by remember { mutableStateOf("Presets ficam salvos neste celular") }

    fun updateTrack(index: Int, newTrack: TrackState) {
        tracks = tracks.mapIndexed { i, old -> if (i == index) newTrack else old }
    }

    fun applyTrackSettings(newTracks: List<TrackState>) {
        tracks = newTracks.take(5).mapIndexed { i, t ->
            val font = library.firstOrNull { it.id == t.soundFontId }
            val maxPreset = (font?.let { engine.presetCount(it.nativeId) } ?: 1) - 1
            val fixed = t.copy(name = "Faixa ${i + 1}", presetIndex = t.presetIndex.coerceIn(0, maxPreset.coerceAtLeast(0)), volume = t.volume.coerceIn(0f, 1f))
            if (loaded && font != null) {
                engine.selectPreset(fixed.presetIndex, i, font.nativeId)
                engine.setTrackVolume(i, if (fixed.enabled) fixed.volume else 0f)
            }
            fixed
        } + List((5 - newTracks.size).coerceAtLeast(0)) { i -> TrackState("Faixa ${newTracks.size + i + 1}") }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            status = "Importando SoundFont para a biblioteca…"
            scope.launch {
                try {
                    val item = withContext(Dispatchers.IO) {
                        // Obtain the real filename from Android's document provider.
                        // uri.lastPathSegment often contains an internal/random document ID.
                        val providerName = context.contentResolver.query(
                            uri,
                            arrayOf(OpenableColumns.DISPLAY_NAME),
                            null,
                            null,
                            null
                        )?.use { cursor ->
                            if (cursor.moveToFirst()) {
                                val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                if (column >= 0) cursor.getString(column) else null
                            } else null
                        }

                        val originalName = providerName
                            ?.takeIf { it.isNotBlank() }
                            ?: uri.lastPathSegment
                                ?.substringAfterLast('/')
                                ?.substringAfterLast(':')
                                ?.takeIf { it.isNotBlank() }
                            ?: "SoundFont.sf2"

                        // Keep the original filename for display, while preventing path separators
                        // from becoming part of the private storage path.
                        val displayName = if (originalName.endsWith(".sf2", ignoreCase = true)) {
                            originalName
                        } else {
                            "$originalName.sf2"
                        }
                        val storageName = displayName
                            .replace('/', '_')
                            .replace('\\', '_')
                            .filterNot { it.code < 32 }
                            .take(120)
                        val clean = if (storageName.endsWith(".sf2", ignoreCase = true)) {
                            storageName
                        } else {
                            "$storageName.sf2"
                        }
                        val file = File(libraryDir, "${UUID.randomUUID()}--$clean")
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Não foi possível abrir o arquivo" }.use { stream ->
                                file.outputStream().use { output -> stream.copyTo(output) }
                            }
                        }
                        val nativeId = engine.loadSoundFont(file)
                        if (nativeId < 0) {
                            file.delete()
                            throw IllegalArgumentException("O arquivo não pôde ser carregado pelo FluidSynth.")
                        }
                        SoundFontItem(file.name, displayName, file, nativeId)
                    }
                    library = library + item
                    loaded = true
                    sf2Name = item.name
                    status = "SoundFont '${item.name}' importado e armazenado na biblioteca."
                    tracks = tracks.mapIndexed { i, t ->
                        if (t.soundFontId.isBlank()) {
                            val count = engine.presetCount(item.nativeId)
                            val preset = if (count > 0) i.coerceAtMost(count - 1) else 0
                            engine.selectPreset(preset, i, item.nativeId)
                            engine.setTrackVolume(i, if (t.enabled) t.volume else 0f)
                            t.copy(soundFontId = item.id, presetIndex = preset)
                        } else t
                    }
                } catch (e: Exception) {
                    status = "Erro ao importar SF2: ${e.message}"
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        val existingFiles = withContext(Dispatchers.IO) {
            libraryDir.listFiles()?.filter { it.isFile && it.extension.equals("sf2", true) } ?: emptyList()
        }
        val restored = mutableListOf<SoundFontItem>()
        for (file in existingFiles) {
            val nativeId = withContext(Dispatchers.IO) { engine.loadSoundFont(file) }
            if (nativeId >= 0) restored.add(SoundFontItem(file.name, file.name.substringAfter("--", file.name), file, nativeId))
        }
        library = restored
        loaded = restored.isNotEmpty()
        if (restored.isNotEmpty()) {
            sf2Name = "${restored.size} SoundFont(s) na biblioteca"
            status = "Biblioteca restaurada: ${restored.size} SoundFont(s)."
            tracks = tracks.mapIndexed { i, t ->
                val font = restored.firstOrNull { it.id == t.soundFontId } ?: restored.first()
                val count = engine.presetCount(font.nativeId)
                val preset = if (count > 0) t.presetIndex.coerceIn(0, count - 1) else 0
                engine.selectPreset(preset, i, font.nativeId)
                engine.setTrackVolume(i, if (t.enabled) t.volume else 0f)
                t.copy(soundFontId = font.id, presetIndex = preset)
            }
        } else status = "Importe um ou mais arquivos .sf2 para a biblioteca."
    }

    DisposableEffect(Unit) {
        onDispose {
            midiDevices.forEach { try { it.close() } catch (_: Exception) {} }
            engine.close()
        }
    }

    fun refreshMidiDevices() {
        try {
            val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
            midiAvailable = manager.devices.filter { it.outputPortCount > 0 }
            midiStatus = if (midiAvailable.isEmpty()) "Nenhum controlador MIDI detectado" else "Encontrados ${midiAvailable.size} controlador(es)"
        } catch (e: Exception) { midiStatus = "Erro ao procurar MIDI: ${e.message}" }
    }

    fun connectMidi(info: MidiDeviceInfo) {
        val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
        val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Controlador MIDI"
        if (midiNames.contains(name)) { midiStatus = "$name já está conectado"; return }
        try {
            manager.openDevice(info, { device ->
                if (device == null) { midiStatus = "Não foi possível abrir $name"; return@openDevice }
                val port = device.openOutputPort(0)
                if (port == null) { device.close(); midiStatus = "Não foi possível abrir a saída de $name"; return@openDevice }
                try {
                    port.connect(object : MidiReceiver() {
                        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                            if (count < 1) return
                            val st = msg[offset].toInt() and 0xFF
                            val type = st and 0xF0
                            if (count >= 3) {
                                val a = msg[offset + 1].toInt() and 0x7F
                                val b = msg[offset + 2].toInt() and 0x7F
                                when (type) {
                                    0x90 -> for (ch in 0 until 5) if (b == 0) engine.noteOff((a + octave * 12 + transpose).coerceIn(0,127), ch) else engine.noteOn((a + octave * 12 + transpose).coerceIn(0,127), b, ch)
                                    0x80 -> for (ch in 0 until 5) engine.noteOff((a + octave * 12 + transpose).coerceIn(0,127), ch)
                                    0xB0 -> {
                                        if (a == ccSustain.toIntOrNull()) for (ch in 0 until 5) engine.setSustain(b >= 64, ch)
                                        if (a == ccMaster.toIntOrNull()) { volume = b / 127f; engine.setVolume(volume) }
                                        listOf(ccTrack1, ccTrack2, ccTrack3, ccTrack4, ccTrack5).forEachIndexed { i, cc ->
                                            if (a == cc.toIntOrNull()) {
                                                val v = b / 127f
                                                tracks = tracks.mapIndexed { j, t -> if (j == i) t.copy(volume = v) else t }
                                                engine.setTrackVolume(i, if (tracks[i].enabled) v else 0f)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    })
                    midiDevices.add(device)
                    midiNames.add(name)
                    midiStatus = "Conectados: ${midiNames.joinToString()}"
                } catch (e: Exception) { try { device.close() } catch (_: Exception) {}; midiStatus = "Erro na porta $name: ${e.message}" }
            }, android.os.Handler(context.mainLooper))
        } catch (e: Exception) { midiStatus = "Erro MIDI: ${e.message}" }
    }

    fun disconnectMidi() {
        midiDevices.forEach { try { it.close() } catch (_: Exception) {} }
        midiDevices.clear()
        midiNames.clear()
        midiStatus = "Todos os controladores desconectados"
    }

    fun saveCurrentPreset() {
        val name = newPresetName.trim()
        if (name.isEmpty()) { presetMessage = "Digite um nome para o preset."; return }
        if (!loaded) { presetMessage = "Carregue um SoundFont antes de salvar."; return }
        val json = JSONObject().apply {
            put("sf2Name", sf2Name)
            put("volume", volume.toDouble())
            put("octave", octave)
            put("transpose", transpose)
            put("sustain", sustain)
            // Mapeamentos MIDI CC fazem parte do preset.
            put("midiCc", JSONObject().apply {
                put("master", ccMaster.toIntOrNull() ?: 7)
                put("sustain", ccSustain.toIntOrNull() ?: 64)
                put("track1", ccTrack1.toIntOrNull() ?: 20)
                put("track2", ccTrack2.toIntOrNull() ?: 21)
                put("track3", ccTrack3.toIntOrNull() ?: 22)
                put("track4", ccTrack4.toIntOrNull() ?: 23)
                put("track5", ccTrack5.toIntOrNull() ?: 24)
            })
            val arr = JSONArray()
            tracks.forEach { t ->
                arr.put(JSONObject().put("soundFontId", t.soundFontId)
                    .put("presetIndex", t.presetIndex).put("volume", t.volume.toDouble())
                    .put("enabled", t.enabled))
            }
            put("tracks", arr)
        }.toString()
        val updated = (savedPresets.filterNot { it.name.equals(name, ignoreCase = true) } + SavedPreset(name, json)).sortedBy { it.name.lowercase() }
        savedPresets = updated
        writeSavedPresets(context, updated)
        newPresetName = ""
        presetMessage = "Preset '$name' salvo."
    }

    fun loadSavedPreset(item: SavedPreset) {
        try {
            if (!loaded || library.isEmpty()) { presetMessage = "Importe primeiro os SoundFonts usados nesse preset."; return }
            val obj = JSONObject(item.json)
            val arr = obj.getJSONArray("tracks")
            val restored = (0 until minOf(5, arr.length())).map { i ->
                val t = arr.getJSONObject(i)
                val requestedId = t.optString("soundFontId", "")
                val fontId = if (library.any { it.id == requestedId }) requestedId else library.first().id
                TrackState("Faixa ${i + 1}", fontId, t.optInt("presetIndex", 0), t.optDouble("volume", 0.8).toFloat(), t.optBoolean("enabled", true))
            }
            applyTrackSettings(restored)
            volume = obj.optDouble("volume", 0.8).toFloat().coerceIn(0f, 1f)
            engine.setVolume(volume)
            octave = obj.optInt("octave", 0).coerceIn(-3, 3)
            transpose = obj.optInt("transpose", 0).coerceIn(-12, 12)
            sustain = obj.optBoolean("sustain", false)
            tracks.forEachIndexed { i, t -> engine.setSustain(sustain, i) }
            // Presets antigos sem midiCc continuam carregando com os mapeamentos padrão.
            val cc = obj.optJSONObject("midiCc")
            ccMaster = (cc?.optInt("master", 7) ?: 7).coerceIn(0, 127).toString()
            ccSustain = (cc?.optInt("sustain", 64) ?: 64).coerceIn(0, 127).toString()
            ccTrack1 = (cc?.optInt("track1", 20) ?: 20).coerceIn(0, 127).toString()
            ccTrack2 = (cc?.optInt("track2", 21) ?: 21).coerceIn(0, 127).toString()
            ccTrack3 = (cc?.optInt("track3", 22) ?: 22).coerceIn(0, 127).toString()
            ccTrack4 = (cc?.optInt("track4", 23) ?: 23).coerceIn(0, 127).toString()
            ccTrack5 = (cc?.optInt("track5", 24) ?: 24).coerceIn(0, 127).toString()
            presetMessage = "Preset '${item.name}' carregado, incluindo mapeamentos MIDI CC."
            tab = "Tocar"
        } catch (e: Exception) { presetMessage = "Não foi possível carregar: ${e.message}" }
    }

    Column(
        Modifier.fillMaxSize().background(bg).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("SF2 PLAYER", fontSize = 24.sp, fontWeight = FontWeight.Black, color = white)
        Text("FluidSynth • biblioteca SF2 0.9.4", fontSize = 13.sp, color = muted)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Tocar", "Biblioteca", "Instrumentos", "Faixas", "Áudio", "Presets", "MIDI / Diagnóstico").forEach {
                FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it) })
            }
        }

        when (tab) {
            "Tocar" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("BIBLIOTECA DE SOUNDFONTS", color = cyan, fontWeight = FontWeight.Bold)
                        Text("${library.size} arquivo(s) armazenado(s)", color = white)
                        Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Importar SoundFont (.sf2)") }
                        Text(status, color = if (loaded) Color(0xFF86EFAC) else Color(0xFFFBBF24), fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CONTROLES GERAIS", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Volume master ${(volume * 100).toInt()}%", color = white)
                        Slider(value = volume, onValueChange = { volume = it; engine.setVolume(it) })
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { octave = (octave - 1).coerceAtLeast(-3) }) { Text("− Oitava") }
                            Text("Oitava $octave", color = white)
                            OutlinedButton(onClick = { octave = (octave + 1).coerceAtMost(3) }) { Text("+ Oitava") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Transposição: $transpose", Modifier.weight(1f))
                            TextButton(onClick = { transpose = (transpose - 1).coerceAtLeast(-12) }) { Text("−") }
                            TextButton(onClick = { transpose = (transpose + 1).coerceAtMost(12) }) { Text("+") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = sustain, onCheckedChange = { sustain = it; tracks.forEachIndexed { i, _ -> engine.setSustain(it, i) } })
                            Text("Sustain em todas as faixas", color = muted, fontSize = 12.sp)
                        }
                        Text("Faixas ativas: ${tracks.count { it.enabled }} de 5", color = muted, fontSize = 12.sp)
                    }
                }
                Text("Entrada de notas pelo teclado MIDI externo", color = cyan, fontWeight = FontWeight.Bold)
                Text("O teclado virtual foi removido. Conecte um controlador MIDI USB compatível para tocar; os controles, a biblioteca e as faixas continuam disponíveis.", color = muted, fontSize = 12.sp)
            }

            "Biblioteca" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("BIBLIOTECA PERMANENTE • ${library.size} SOUNDFONT(S)", color = cyan, fontWeight = FontWeight.Bold)
                Text("Os arquivos importados ficam guardados no armazenamento privado do aplicativo. Escolha um arquivo diferente em cada faixa.", color = muted, fontSize = 12.sp)
                Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Importar arquivo .sf2") }
                if (library.isEmpty()) Text("Nenhum SoundFont importado.", color = muted)
                library.forEach { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(item.name, color = white, fontWeight = FontWeight.Bold)
                                Text("${item.file.length() / 1024} KB • ${tracks.count { it.soundFontId == item.id }} faixa(s) usando este arquivo", color = muted, fontSize = 11.sp)
                            }
                            OutlinedButton(
                                enabled = tracks.none { it.soundFontId == item.id },
                                onClick = {
                                    if (item.file.delete()) {
                                        library = library.filterNot { it.id == item.id }
                                        status = "SoundFont removido da biblioteca."
                                        if (library.isEmpty()) { loaded = false; sf2Name = "Biblioteca vazia" }
                                    } else status = "Não foi possível excluir o arquivo."
                                }
                            ) { Text("Excluir") }
                        }
                    }
                }
                Text(status, color = muted, fontSize = 12.sp)
            }

            "Instrumentos" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Os instrumentos são selecionados por faixa na aba Faixas.", color = white)
                Text("Cada faixa mostra os timbres disponíveis no SoundFont escolhido para ela.", color = muted)
            }

            "Faixas" -> {
                val landscape = androidx.compose.ui.platform.LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("MESA DE SOM • 5 FAIXAS", color = cyan, fontWeight = FontWeight.Bold)
                    Text("Escolha o SoundFont e o timbre de cada faixa independentemente.", color = muted, fontSize = 12.sp)
                    if (library.isEmpty()) Text("Importe arquivos na aba Biblioteca primeiro.", color = white)
                    if (landscape) {
                        Row(Modifier.fillMaxWidth().weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            tracks.forEachIndexed { i, track ->
                                TrackMixerCard(i, track, library, engine, onUpdate = { updateTrack(i, it) }, modifier = Modifier.width(245.dp).fillMaxHeight())
                            }
                        }
                    } else {
                        Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            tracks.forEachIndexed { i, track ->
                                TrackMixerCard(i, track, library, engine, onUpdate = { updateTrack(i, it) }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }

            "Áudio" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("LATÊNCIA / BUFFER", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Buffer: $bufferFrames frames", color = white)
                        Slider(value = bufferFrames.toFloat(), onValueChange = { v -> bufferFrames = listOf(128, 256, 512, 1024).minBy { kotlin.math.abs(it - v) } }, valueRange = 128f..1024f, steps = 2, onValueChangeFinished = { engine.setBufferFrames(bufferFrames) })
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(128, 256, 512, 1024).forEach { n -> FilterChip(selected = bufferFrames == n, onClick = { bufferFrames = n; engine.setBufferFrames(n) }, label = { Text("$n") }) } }
                        Text("Menor buffer = menor latência, mas pode causar estalos. 256 ou 512 é um bom ponto de partida.", color = muted, fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CURVA DE VELOCITY", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Curva: ${"%.2f".format(velocityCurve)}", color = white)
                        Slider(value = velocityCurve, onValueChange = { velocityCurve = it; engine.velocityCurve = it }, valueRange = 0.5f..2f)
                        Text("Suave (0,5) responde mais às notas fracas; Linear (1,0) mantém a resposta original; Forte (2,0) exige mais força para atingir velocidades altas.", color = muted, fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("EFEITOS DO FLUIDSYNTH", color = cyan, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = reverbEnabled, onCheckedChange = { reverbEnabled = it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }); Text("Reverb", color = white) }
                        Text("Intensidade: ${(reverbLevel*100).toInt()}%", color = white)
                        Slider(value = reverbLevel, onValueChange = { reverbLevel=it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }, enabled = reverbEnabled)
                        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = chorusEnabled, onCheckedChange = { chorusEnabled = it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }); Text("Chorus", color = white) }
                        Text("Intensidade: ${(chorusLevel*100).toInt()}%", color = white)
                        Slider(value = chorusLevel, onValueChange = { chorusLevel=it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }, valueRange = 0f..1f, enabled = chorusEnabled)
                    }
                }
            }

            "Presets" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SALVAR CONFIGURAÇÃO", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Salva volume master, oitava, transposição, sustain, mapeamentos MIDI e o SoundFont, timbre, volume e ativação de cada faixa.", color = muted, fontSize = 12.sp)
                        OutlinedTextField(value = newPresetName, onValueChange = { newPresetName = it }, label = { Text("Nome do preset") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { saveCurrentPreset() }, modifier = Modifier.fillMaxWidth(), enabled = loaded) { Text("Salvar preset atual") }
                        Text(presetMessage, color = if (presetMessage.startsWith("Não") || presetMessage.startsWith("Carregue") || presetMessage.startsWith("Digite")) Color(0xFFFBBF24) else muted, fontSize = 12.sp)
                    }
                }
                Text("PRESETS SALVOS (${savedPresets.size})", color = cyan, fontWeight = FontWeight.Bold)
                if (savedPresets.isEmpty()) Text("Nenhum preset salvo ainda.", color = muted)
                savedPresets.forEach { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(item.name, color = white, modifier = Modifier.weight(1f))
                            Button(onClick = { loadSavedPreset(item) }) { Text("Carregar") }
                            OutlinedButton(onClick = {
                                savedPresets = savedPresets.filterNot { it.name == item.name }
                                writeSavedPresets(context, savedPresets)
                                presetMessage = "Preset '${item.name}' removido."
                            }) { Text("Excluir") }
                        }
                    }
                }
            }

            else -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("CONTROLADORES MIDI", color = cyan, fontWeight = FontWeight.Bold)
                        Text(midiStatus, color = white)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { refreshMidiDevices() }, modifier = Modifier.weight(1f)) { Text("Procurar") }
                            OutlinedButton(onClick = { disconnectMidi() }, modifier = Modifier.weight(1f)) { Text("Desconectar todos") }
                        }
                        if (midiAvailable.isEmpty()) Text("Toque em Procurar para listar controladores USB MIDI.", color = muted, fontSize = 12.sp)
                        midiAvailable.forEach { info ->
                            val deviceName = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Controlador MIDI"
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(deviceName, color = white, modifier = Modifier.weight(1f))
                                Button(onClick = { connectMidi(info) }, enabled = !midiNames.contains(deviceName)) { Text(if (midiNames.contains(deviceName)) "Conectado" else "Conectar") }
                            }
                        }
                        Text("MAPEAMENTO MIDI CC", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Informe os números CC (0–127) enviados pelo controlador.", color = muted, fontSize = 12.sp)
                        OutlinedTextField(value = ccMaster, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccMaster = it }, label = { Text("CC volume master") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccSustain, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccSustain = it }, label = { Text("CC sustain") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack1, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack1 = it }, label = { Text("CC volume faixa 1") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack2, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack2 = it }, label = { Text("CC volume faixa 2") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack3, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack3 = it }, label = { Text("CC volume faixa 3") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack4, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack4 = it }, label = { Text("CC volume faixa 4") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack5, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack5 = it }, label = { Text("CC volume faixa 5") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("Padrões: CC7 master, CC64 sustain, CC20–24 volumes das faixas. Todos os controladores conectados podem tocar as faixas.", color = muted, fontSize = 12.sp)
                        Text("Motor SF2: ${if (loaded) "carregado" else "não carregado"}", color = white)
                        Text(status, color = muted)
                    }
                }
            }
        }
    }
}

private fun readSavedPresets(context: Context): List<SavedPreset> {
    return try {
        val raw = context.getSharedPreferences("sf2_player", Context.MODE_PRIVATE).getString("presets", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); SavedPreset(o.getString("name"), o.getString("json")) }
    } catch (_: Exception) { emptyList() }
}

private fun writeSavedPresets(context: Context, presets: List<SavedPreset>) {
    val arr = JSONArray()
    presets.forEach { arr.put(JSONObject().put("name", it.name).put("json", it.json)) }
    context.getSharedPreferences("sf2_player", Context.MODE_PRIVATE).edit().putString("presets", arr.toString()).apply()
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrackMixerCard(
    index: Int,
    track: TrackState,
    library: List<SoundFontItem>,
    engine: NativeSynth,
    onUpdate: (TrackState) -> Unit,
    modifier: Modifier = Modifier
) {
    val whiteColor = white
    val font = library.firstOrNull { it.id == track.soundFontId }
    val count = font?.let { engine.presetCount(it.nativeId) } ?: 0
    val presetIndex = if (count > 0) track.presetIndex.coerceIn(0, count - 1) else 0
    var soundFontExpanded by remember(index) { mutableStateOf(false) }
    var presetExpanded by remember(index, track.soundFontId) { mutableStateOf(false) }

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("FAIXA ${index + 1}", color = cyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Checkbox(
                    checked = track.enabled,
                    onCheckedChange = { enabled ->
                        val updated = track.copy(enabled = enabled)
                        onUpdate(updated)
                        engine.setTrackVolume(index, if (enabled) updated.volume else 0f)
                    }
                )
            }

            ExposedDropdownMenuBox(
                expanded = soundFontExpanded,
                onExpandedChange = { soundFontExpanded = it }
            ) {
                OutlinedTextField(
                    value = font?.name ?: "Escolher SoundFont",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("SoundFont desta faixa") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(soundFontExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = soundFontExpanded,
                    onDismissRequest = { soundFontExpanded = false }
                ) {
                    library.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item.name) },
                            onClick = {
                                val n = engine.presetCount(item.nativeId)
                                val nextPreset = if (n > 0) 0 else 0
                                onUpdate(track.copy(soundFontId = item.id, presetIndex = nextPreset))
                                if (n > 0) engine.selectPreset(nextPreset, index, item.nativeId)
                                engine.setTrackVolume(index, if (track.enabled) track.volume else 0f)
                                soundFontExpanded = false
                            }
                        )
                    }
                }
            }

            if (font != null && count > 0) {
                ExposedDropdownMenuBox(
                    expanded = presetExpanded,
                    onExpandedChange = { presetExpanded = it }
                ) {
                    OutlinedTextField(
                        value = engine.presetName(presetIndex, font.nativeId),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Timbre / programa") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(presetExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = presetExpanded,
                        onDismissRequest = { presetExpanded = false }
                    ) {
                        (0 until count).forEach { program ->
                            DropdownMenuItem(
                                text = { Text(engine.presetName(program, font.nativeId)) },
                                onClick = {
                                    onUpdate(track.copy(presetIndex = program))
                                    engine.selectPreset(program, index, font.nativeId)
                                    presetExpanded = false
                                }
                            )
                        }
                    }
                }
            } else {
                Text(
                    if (font == null) "Escolha um SoundFont na lista." else "Este arquivo não possui presets legíveis.",
                    color = muted,
                    fontSize = 12.sp
                )
            }

            Text("Volume: ${(track.volume * 100).toInt()}%", color = whiteColor, fontSize = 13.sp)
            Slider(
                value = track.volume,
                onValueChange = { v ->
                    val updated = track.copy(volume = v)
                    onUpdate(updated)
                    engine.setTrackVolume(index, if (track.enabled) v else 0f)
                },
                enabled = font != null && engine.loaded
            )
            Text(if (track.enabled) "Ativa" else "Muda", color = muted, fontSize = 12.sp)
        }
    }
}
