#include <jni.h>
#include <stdlib.h>
#include <stdint.h>
#include <pthread.h>
#define TSF_IMPLEMENTATION
#include "tsf.h"
static tsf *synth = NULL;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
JNIEXPORT jboolean JNICALL Java_br_com_sf2player_NativeSynth_loadNative(JNIEnv *env, jobject thiz, jstring path, jint rate) {
 const char *p=(*env)->GetStringUTFChars(env,path,0); if(!p) return JNI_FALSE;
 pthread_mutex_lock(&lock); if(synth){tsf_close(synth); synth=NULL;} synth=tsf_load_filename(p);
 if(synth){tsf_set_output(synth, TSF_STEREO_INTERLEAVED, rate, 0.8f); tsf_set_max_voices(synth,128);}
 pthread_mutex_unlock(&lock); (*env)->ReleaseStringUTFChars(env,path,p); return synth?JNI_TRUE:JNI_FALSE;
}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_noteOnNative(JNIEnv *e,jobject o,jint key,jint vel){pthread_mutex_lock(&lock);if(synth)tsf_note_on(synth,0,key,(float)vel/127.0f);pthread_mutex_unlock(&lock);}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_noteOffNative(JNIEnv *e,jobject o,jint key){pthread_mutex_lock(&lock);if(synth)tsf_note_off(synth,0,key);pthread_mutex_unlock(&lock);}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_volumeNative(JNIEnv *e,jobject o,jfloat v){pthread_mutex_lock(&lock);if(synth)tsf_set_volume(synth,v);pthread_mutex_unlock(&lock);}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_renderNative(JNIEnv *e,jobject o,jshortArray arr,jint frames){jsize n=(*e)->GetArrayLength(e,arr);if(n<frames*2)return;jshort *out=(*e)->GetShortArrayElements(e,arr,NULL);pthread_mutex_lock(&lock);if(synth)tsf_render_short(synth,out,frames,0);else for(int i=0;i<frames*2;i++)out[i]=0;pthread_mutex_unlock(&lock);(*e)->ReleaseShortArrayElements(e,arr,out,0);}
JNIEXPORT void JNICALL Java_br_com_sf2player_NativeSynth_closeNative(JNIEnv *e,jobject o){pthread_mutex_lock(&lock);if(synth){tsf_close(synth);synth=NULL;}pthread_mutex_unlock(&lock);}
