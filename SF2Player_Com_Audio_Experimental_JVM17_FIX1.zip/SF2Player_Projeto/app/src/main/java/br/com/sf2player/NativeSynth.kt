package br.com.sf2player

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.AudioManager
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class NativeSynth {
    companion object { init { System.loadLibrary("sf2native") } }
    private external fun loadNative(path: String, rate: Int): Boolean
    private external fun noteOnNative(key: Int, velocity: Int)
    private external fun noteOffNative(key: Int)
    private external fun volumeNative(volume: Float)
    private external fun renderNative(buffer: ShortArray, frames: Int)
    private external fun closeNative()
    private var track: AudioTrack? = null
    private val running = AtomicBoolean(false)
    @Volatile var loaded = false; private set
    @Volatile var status = "Selecione um SoundFont"; private set
    fun load(file: File, rate: Int = 44100): Boolean {
        stopAudio(); loaded = loadNative(file.absolutePath, rate)
        status = if (loaded) "SoundFont carregado; motor SF2 ativo" else "Não foi possível ler este SF2"
        if (loaded) startAudio(rate)
        return loaded
    }
    private fun startAudio(rate: Int) {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        val t = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()).setBufferSizeInBytes(min * 2).setTransferMode(AudioTrack.MODE_STREAM).build()
        track = t; running.set(true); t.play()
        Thread({ val frames=512; val buf=ShortArray(frames*2); while(running.get()) { renderNative(buf,frames); val bytes=frames*4; var offset=0; while(offset<bytes && running.get()) { val wrote=t.write(buf,offset/2,(bytes-offset)/2,AudioTrack.WRITE_BLOCKING); if(wrote<0) break; offset += wrote*2 } } }, "SF2-Audio").apply { priority=Thread.MAX_PRIORITY; start() }
    }
    fun noteOn(key:Int, velocity:Int=100) { if(loaded) noteOnNative(key.coerceIn(0,127),velocity.coerceIn(1,127)) }
    fun noteOff(key:Int) { if(loaded) noteOffNative(key.coerceIn(0,127)) }
    fun setVolume(v:Float) { volumeNative(v.coerceIn(0f,1f)) }
    fun stopAudio() { running.set(false); try { track?.pause(); track?.flush(); track?.stop(); track?.release() } catch (_:Exception) {}; track=null }
    fun close() { stopAudio(); closeNative(); loaded=false }
}
