# SF2 Player 0.2 — áudio experimental

Esta versão adiciona uma interface de teclado e um motor nativo experimental usando TinySoundFont (licença MIT). O workflow busca o cabeçalho oficial do TinySoundFont no GitHub durante a compilação, instala NDK/CMake e tenta produzir o APK.

## Importante
- Ainda não foi possível executar uma compilação Android neste ambiente. O primeiro GitHub Actions é o teste real.
- O teclado da tela envia note-on/note-off ao motor quando um SF2 é carregado.
- O motor usa o primeiro preset e não oferece ainda navegação completa por bancos/programas.
- MIDI USB é apenas detectado preliminarmente; a entrada de notas não está conectada ao motor nesta versão.
- O TinySoundFont não implementa todos os recursos do padrão SF2; efeitos de chorus/reverb e moduladores podem não ser reproduzidos fielmente.
- Volume master é ligado ao motor. Controles de filtro por faixa, mixer multicanal, sustain real, MP3 e presets completos não estão incluídos nesta versão simplificada.

## Compilar no celular
1. Crie um repositório privado no GitHub.
2. Extraia o conteúdo interno de `SF2Player_Projeto` e envie os arquivos para a raiz do repositório, mantendo a pasta `.github`.
3. Abra Actions → Compilar SF2 Player → Run workflow.
4. Se terminar verde, abra a execução e baixe `SF2Player-apk-debug`. Extraia e instale `app-debug.apk`.
5. Se falhar, envie as últimas 30–50 linhas do log para correção.

O workflow baixa `tsf.h` e o arquivo de licença do repositório oficial TinySoundFont durante a compilação. Não remova o aviso de licença incluído no projeto.
