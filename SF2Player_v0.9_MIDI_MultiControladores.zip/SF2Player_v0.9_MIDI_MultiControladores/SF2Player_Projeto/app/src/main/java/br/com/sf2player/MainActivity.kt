package br.com.sf2player

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private val bg = Color(0xFF0D1117)
private val panel = Color(0xFF171F2B)
private val cyan = Color(0xFF38BDF8)
private val white = Color(0xFFF8FAFC)
private val muted = Color(0xFF9CA3AF)

private data class TrackState(
    val name: String,
    val presetIndex: Int = 0,
    val volume: Float = 0.8f,
    val enabled: Boolean = true
)

private data class SavedPreset(val name: String, val json: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 17, 23)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = bg, surface = panel, onBackground = white, onSurface = white)) {
                PlayerScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { NativeSynth() }

    var sf2Name by remember { mutableStateOf("Nenhum SoundFont selecionado") }
    var status by remember { mutableStateOf("Escolha um arquivo .sf2 para começar") }
    var loaded by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(0.8f) }
    var octave by remember { mutableIntStateOf(0) }
    var transpose by remember { mutableIntStateOf(0) }
    var sustain by remember { mutableStateOf(false) }
    var bufferFrames by remember { mutableIntStateOf(256) }
    var velocityCurve by remember { mutableFloatStateOf(1.0f) }
    var reverbEnabled by remember { mutableStateOf(true) }
    var reverbLevel by remember { mutableFloatStateOf(0.35f) }
    var chorusEnabled by remember { mutableStateOf(true) }
    var chorusLevel by remember { mutableFloatStateOf(0.25f) }
    var active by remember { mutableStateOf(setOf<Int>()) }
    var tab by remember { mutableStateOf("Tocar") }
    var midiStatus by remember { mutableStateOf("MIDI USB: desconectado") }
    val midiDevices = remember { mutableStateListOf<MidiDevice>() }
    val midiNames = remember { mutableStateListOf<String>() }
    var midiAvailable by remember { mutableStateOf<List<MidiDeviceInfo>>(emptyList()) }
    var ccMaster by remember { mutableStateOf("7") }
    var ccSustain by remember { mutableStateOf("64") }
    var ccTrack1 by remember { mutableStateOf("20") }
    var ccTrack2 by remember { mutableStateOf("21") }
    var ccTrack3 by remember { mutableStateOf("22") }
    var ccTrack4 by remember { mutableStateOf("23") }
    var ccTrack5 by remember { mutableStateOf("24") }
    var tracks by remember { mutableStateOf(List(5) { i -> TrackState("Faixa ${i + 1}", i, 0.8f, i == 0) }) }
    var newPresetName by remember { mutableStateOf("") }
    var savedPresets by remember { mutableStateOf(readSavedPresets(context)) }
    var presetMessage by remember { mutableStateOf("Presets ficam salvos neste celular") }

    fun updateTrack(index: Int, newTrack: TrackState) {
        tracks = tracks.mapIndexed { i, old -> if (i == index) newTrack else old }
    }

    fun applyTrackSettings(newTracks: List<TrackState>) {
        tracks = newTracks.take(5).mapIndexed { i, t ->
            val fixed = t.copy(name = "Faixa ${i + 1}", presetIndex = t.presetIndex.coerceIn(0, (engine.presetCount() - 1).coerceAtLeast(0)), volume = t.volume.coerceIn(0f, 1f))
            if (loaded) {
                engine.selectPreset(fixed.presetIndex, i)
                engine.setTrackVolume(i, if (fixed.enabled) fixed.volume else 0f)
            }
            fixed
        } + List((5 - newTracks.size).coerceAtLeast(0)) { i -> TrackState("Faixa ${newTracks.size + i + 1}") }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            status = "Copiando SoundFont…"
            sf2Name = uri.lastPathSegment?.substringAfterLast('/') ?: "SoundFont.sf2"
            scope.launch {
                try {
                    val file = withContext(Dispatchers.IO) {
                        val f = File(context.filesDir, "active-soundfont.sf2")
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Não foi possível abrir o arquivo" }.copyTo(f.outputStream())
                        }
                        f
                    }
                    loaded = engine.load(file)
                    status = engine.status
                    if (loaded) {
                        val count = engine.presetCount()
                        val initial = List(5) { i -> TrackState("Faixa ${i + 1}", if (count > 0) i.coerceAtMost(count - 1) else 0, 0.8f, i == 0) }
                        tracks = initial
                        initial.forEachIndexed { i, t -> engine.selectPreset(t.presetIndex, i); engine.setTrackVolume(i, if (t.enabled) t.volume else 0f) }
                    }
                } catch (e: Exception) {
                    loaded = false
                    status = "Erro: ${e.message}"
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            midiDevices.forEach { try { it.close() } catch (_: Exception) {} }
            engine.close()
        }
    }

    fun refreshMidiDevices() {
        try {
            val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
            midiAvailable = manager.devices.filter { it.outputPortCount > 0 }
            midiStatus = if (midiAvailable.isEmpty()) "Nenhum controlador MIDI detectado" else "Encontrados ${midiAvailable.size} controlador(es)"
        } catch (e: Exception) { midiStatus = "Erro ao procurar MIDI: ${e.message}" }
    }

    fun connectMidi(info: MidiDeviceInfo) {
        val manager = context.getSystemService(Context.MIDI_SERVICE) as MidiManager
        val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Controlador MIDI"
        if (midiNames.contains(name)) { midiStatus = "$name já está conectado"; return }
        try {
            manager.openDevice(info, { device ->
                if (device == null) { midiStatus = "Não foi possível abrir $name"; return@openDevice }
                val port = device.openOutputPort(0)
                if (port == null) { device.close(); midiStatus = "Não foi possível abrir a saída de $name"; return@openDevice }
                try {
                    port.connect(object : MidiReceiver() {
                        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                            if (count < 1) return
                            val st = msg[offset].toInt() and 0xFF
                            val type = st and 0xF0
                            if (count >= 3) {
                                val a = msg[offset + 1].toInt() and 0x7F
                                val b = msg[offset + 2].toInt() and 0x7F
                                when (type) {
                                    0x90 -> for (ch in 0 until 5) if (b == 0) engine.noteOff((a + octave * 12 + transpose).coerceIn(0,127), ch) else engine.noteOn((a + octave * 12 + transpose).coerceIn(0,127), b, ch)
                                    0x80 -> for (ch in 0 until 5) engine.noteOff((a + octave * 12 + transpose).coerceIn(0,127), ch)
                                    0xB0 -> {
                                        if (a == ccSustain.toIntOrNull()) for (ch in 0 until 5) engine.setSustain(b >= 64, ch)
                                        if (a == ccMaster.toIntOrNull()) { volume = b / 127f; engine.setVolume(volume) }
                                        listOf(ccTrack1, ccTrack2, ccTrack3, ccTrack4, ccTrack5).forEachIndexed { i, cc ->
                                            if (a == cc.toIntOrNull()) {
                                                val v = b / 127f
                                                tracks = tracks.mapIndexed { j, t -> if (j == i) t.copy(volume = v) else t }
                                                engine.setTrackVolume(i, if (tracks[i].enabled) v else 0f)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    })
                    midiDevices.add(device)
                    midiNames.add(name)
                    midiStatus = "Conectados: ${midiNames.joinToString()}"
                } catch (e: Exception) { try { device.close() } catch (_: Exception) {}; midiStatus = "Erro na porta $name: ${e.message}" }
            }, android.os.Handler(context.mainLooper))
        } catch (e: Exception) { midiStatus = "Erro MIDI: ${e.message}" }
    }

    fun disconnectMidi() {
        midiDevices.forEach { try { it.close() } catch (_: Exception) {} }
        midiDevices.clear()
        midiNames.clear()
        midiStatus = "Todos os controladores desconectados"
    }

    fun saveCurrentPreset() {
        val name = newPresetName.trim()
        if (name.isEmpty()) { presetMessage = "Digite um nome para o preset."; return }
        if (!loaded) { presetMessage = "Carregue um SoundFont antes de salvar."; return }
        val json = JSONObject().apply {
            put("sf2Name", sf2Name)
            put("volume", volume.toDouble())
            put("octave", octave)
            put("transpose", transpose)
            put("sustain", sustain)
            val arr = JSONArray()
            tracks.forEach { t -> arr.put(JSONObject().put("presetIndex", t.presetIndex).put("volume", t.volume.toDouble()).put("enabled", t.enabled)) }
            put("tracks", arr)
        }.toString()
        val updated = (savedPresets.filterNot { it.name.equals(name, ignoreCase = true) } + SavedPreset(name, json)).sortedBy { it.name.lowercase() }
        savedPresets = updated
        writeSavedPresets(context, updated)
        newPresetName = ""
        presetMessage = "Preset '$name' salvo."
    }

    fun loadSavedPreset(item: SavedPreset) {
        try {
            if (!loaded) { presetMessage = "Carregue primeiro o SoundFont usado nesse preset."; return }
            val obj = JSONObject(item.json)
            val arr = obj.getJSONArray("tracks")
            val restored = (0 until minOf(5, arr.length())).map { i ->
                val t = arr.getJSONObject(i)
                TrackState("Faixa ${i + 1}", t.optInt("presetIndex", 0), t.optDouble("volume", 0.8).toFloat(), t.optBoolean("enabled", true))
            }
            applyTrackSettings(restored)
            volume = obj.optDouble("volume", 0.8).toFloat().coerceIn(0f, 1f)
            engine.setVolume(volume)
            octave = obj.optInt("octave", 0).coerceIn(-3, 3)
            transpose = obj.optInt("transpose", 0).coerceIn(-12, 12)
            sustain = obj.optBoolean("sustain", false)
            tracks.forEachIndexed { i, t -> engine.setSustain(sustain, i) }
            presetMessage = "Preset '${item.name}' carregado."
            tab = "Tocar"
        } catch (e: Exception) { presetMessage = "Não foi possível carregar: ${e.message}" }
    }

    Column(
        Modifier.fillMaxSize().background(bg).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("SF2 PLAYER", fontSize = 24.sp, fontWeight = FontWeight.Black, color = white)
        Text("FluidSynth • versão experimental 0.8", fontSize = 13.sp, color = muted)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Tocar", "Instrumentos", "Faixas", "Áudio", "Presets", "MIDI / Diagnóstico").forEach {
                FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it) })
            }
        }

        when (tab) {
            "Tocar" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SOUNDFONT", color = cyan, fontWeight = FontWeight.Bold)
                        Text(sf2Name, color = white)
                        Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Abrir SoundFont (.sf2)") }
                        Text(status, color = if (loaded) Color(0xFF86EFAC) else Color(0xFFFBBF24), fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CONTROLES GERAIS", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Volume master ${(volume * 100).toInt()}%", color = white)
                        Slider(value = volume, onValueChange = { volume = it; engine.setVolume(it) })
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { octave = (octave - 1).coerceAtLeast(-3) }) { Text("− Oitava") }
                            Text("Oitava $octave", color = white)
                            OutlinedButton(onClick = { octave = (octave + 1).coerceAtMost(3) }) { Text("+ Oitava") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Transposição: $transpose", Modifier.weight(1f))
                            TextButton(onClick = { transpose = (transpose - 1).coerceAtLeast(-12) }) { Text("−") }
                            TextButton(onClick = { transpose = (transpose + 1).coerceAtMost(12) }) { Text("+") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = sustain, onCheckedChange = { sustain = it; tracks.forEachIndexed { i, _ -> engine.setSustain(it, i) } })
                            Text("Sustain em todas as faixas", color = muted, fontSize = 12.sp)
                        }
                        Text("Faixas ativas: ${tracks.count { it.enabled }} de 5", color = muted, fontSize = 12.sp)
                    }
                }
                Text("TECLADO • C2–C6", color = cyan, fontWeight = FontWeight.Bold)
                val enabledChannels = tracks.mapIndexedNotNull { i, t -> if (t.enabled) i else null }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    (36..83).forEach { key ->
                        val isBlack = key % 12 in listOf(1, 3, 6, 8, 10)
                        val down = key in active
                        Surface(
                            color = if (down) cyan else if (isBlack) Color(0xFF303846) else Color(0xFFE5E7EB),
                            shape = RoundedCornerShape(5.dp),
                            modifier = Modifier.width(if (isBlack) 35.dp else 42.dp).height(if (isBlack) 116.dp else 150.dp)
                                .pointerInput(key, octave, transpose, loaded, enabledChannels) {
                                    awaitEachGesture {
                                        awaitFirstDown()
                                        val note = key + octave * 12 + transpose
                                        if (loaded && note in 0..127) {
                                            enabledChannels.forEach { ch -> engine.noteOn(note, 100, ch) }
                                            active = active + key
                                        }
                                        waitForUpOrCancellation()
                                        if (loaded && note in 0..127) {
                                            enabledChannels.forEach { ch -> engine.noteOff(note, ch) }
                                            active = active - key
                                        }
                                    }
                                }
                        ) {
                            Box(Modifier.fillMaxSize().padding(bottom = 8.dp), contentAlignment = Alignment.BottomCenter) {
                                Text(if (key % 12 == 0) "C${key / 12 - 1}" else "", color = if (isBlack && !down) white else Color.DarkGray, fontSize = 10.sp)
                            }
                        }
                    }
                }
                Text("As teclas tocam simultaneamente todas as faixas ativadas.", color = muted, fontSize = 12.sp)
            }

            "Instrumentos" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("INSTRUMENTO DA FAIXA 1", color = cyan, fontWeight = FontWeight.Bold)
                        if (!loaded) Text("Importe um SoundFont primeiro.", color = muted)
                        else if (engine.presetCount() == 0) Text("Este SF2 não contém presets legíveis.", color = muted)
                        else {
                            var expanded by remember { mutableStateOf(false) }
                            val selected = tracks[0].presetIndex.coerceIn(0, engine.presetCount() - 1)
                            Text("${selected + 1} de ${engine.presetCount()}: ${engine.presetName(selected)}", color = white)
                            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                                OutlinedTextField(value = engine.presetName(selected), onValueChange = {}, readOnly = true, label = { Text("Instrumento") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    (0 until engine.presetCount()).forEach { idx ->
                                        DropdownMenuItem(text = { Text(engine.presetName(idx)) }, onClick = {
                                            updateTrack(0, tracks[0].copy(presetIndex = idx)); engine.selectPreset(idx, 0); expanded = false
                                        })
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { val idx = (tracks[0].presetIndex - 1).coerceAtLeast(0); updateTrack(0, tracks[0].copy(presetIndex = idx)); engine.selectPreset(idx, 0) }) { Text("Anterior") }
                                OutlinedButton(onClick = { val idx = (tracks[0].presetIndex + 1).coerceAtMost(engine.presetCount() - 1); updateTrack(0, tracks[0].copy(presetIndex = idx)); engine.selectPreset(idx, 0) }) { Text("Próximo") }
                            }
                            Text("Para configurar os outros instrumentos, abra a aba Faixas.", color = muted, fontSize = 12.sp)
                        }
                    }
                }
            }

            "Faixas" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("MESA DE INSTRUMENTOS • 5 FAIXAS", color = cyan, fontWeight = FontWeight.Bold)
                Text("Cada faixa tem seu próprio timbre, volume e botão de ativação. O teclado toca todas as faixas ativadas.", color = muted, fontSize = 12.sp)
                if (!loaded) Text("Carregue um SoundFont para configurar as faixas.", color = white)
                tracks.forEachIndexed { i, track ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(track.name, color = cyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Checkbox(checked = track.enabled, onCheckedChange = { enabled ->
                                    val updated = track.copy(enabled = enabled); updateTrack(i, updated); engine.setTrackVolume(i, if (enabled) updated.volume else 0f)
                                })
                                Text(if (track.enabled) "Ativa" else "Muda", color = muted, fontSize = 12.sp)
                            }
                            if (loaded && engine.presetCount() > 0) {
                                var expanded by remember(i) { mutableStateOf(false) }
                                val idx = track.presetIndex.coerceIn(0, engine.presetCount() - 1)
                                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                                    OutlinedTextField(value = engine.presetName(idx), onValueChange = {}, readOnly = true, label = { Text("Timbre") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                        (0 until engine.presetCount()).forEach { pidx ->
                                            DropdownMenuItem(text = { Text(engine.presetName(pidx)) }, onClick = {
                                                updateTrack(i, track.copy(presetIndex = pidx)); engine.selectPreset(pidx, i); expanded = false
                                            })
                                        }
                                    }
                                }
                            }
                            Text("Volume da faixa: ${(track.volume * 100).toInt()}%", color = white, fontSize = 13.sp)
                            Slider(value = track.volume, onValueChange = { v ->
                                updateTrack(i, track.copy(volume = v)); engine.setTrackVolume(i, if (track.enabled) v else 0f)
                            }, enabled = loaded)
                        }
                    }
                }
            }

            "Áudio" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("LATÊNCIA / BUFFER", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Buffer: $bufferFrames frames", color = white)
                        Slider(value = bufferFrames.toFloat(), onValueChange = { v -> bufferFrames = listOf(128, 256, 512, 1024).minBy { kotlin.math.abs(it - v) } }, valueRange = 128f..1024f, steps = 2, onValueChangeFinished = { engine.setBufferFrames(bufferFrames) })
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(128, 256, 512, 1024).forEach { n -> FilterChip(selected = bufferFrames == n, onClick = { bufferFrames = n; engine.setBufferFrames(n) }, label = { Text("$n") }) } }
                        Text("Menor buffer = menor latência, mas pode causar estalos. 256 ou 512 é um bom ponto de partida.", color = muted, fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CURVA DE VELOCITY", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Curva: ${"%.2f".format(velocityCurve)}", color = white)
                        Slider(value = velocityCurve, onValueChange = { velocityCurve = it; engine.velocityCurve = it }, valueRange = 0.5f..2f)
                        Text("Suave (0,5) responde mais às notas fracas; Linear (1,0) mantém a resposta original; Forte (2,0) exige mais força para atingir velocidades altas.", color = muted, fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("EFEITOS DO FLUIDSYNTH", color = cyan, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = reverbEnabled, onCheckedChange = { reverbEnabled = it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }); Text("Reverb", color = white) }
                        Text("Intensidade: ${(reverbLevel*100).toInt()}%", color = white)
                        Slider(value = reverbLevel, onValueChange = { reverbLevel=it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }, enabled = reverbEnabled)
                        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = chorusEnabled, onCheckedChange = { chorusEnabled = it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }); Text("Chorus", color = white) }
                        Text("Intensidade: ${(chorusLevel*100).toInt()}%", color = white)
                        Slider(value = chorusLevel, onValueChange = { chorusLevel=it; engine.setEffects(reverbEnabled,reverbLevel,chorusEnabled,chorusLevel) }, valueRange = 0f..1f, enabled = chorusEnabled)
                    }
                }
            }

            "Presets" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SALVAR CONFIGURAÇÃO", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Salva volume master, oitava, transposição, sustain, timbres e volumes/ativação das cinco faixas. Para carregar, mantenha carregado o mesmo arquivo SF2.", color = muted, fontSize = 12.sp)
                        OutlinedTextField(value = newPresetName, onValueChange = { newPresetName = it }, label = { Text("Nome do preset") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { saveCurrentPreset() }, modifier = Modifier.fillMaxWidth(), enabled = loaded) { Text("Salvar preset atual") }
                        Text(presetMessage, color = if (presetMessage.startsWith("Não") || presetMessage.startsWith("Carregue") || presetMessage.startsWith("Digite")) Color(0xFFFBBF24) else muted, fontSize = 12.sp)
                    }
                }
                Text("PRESETS SALVOS (${savedPresets.size})", color = cyan, fontWeight = FontWeight.Bold)
                if (savedPresets.isEmpty()) Text("Nenhum preset salvo ainda.", color = muted)
                savedPresets.forEach { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(item.name, color = white, modifier = Modifier.weight(1f))
                            Button(onClick = { loadSavedPreset(item) }) { Text("Carregar") }
                            OutlinedButton(onClick = {
                                savedPresets = savedPresets.filterNot { it.name == item.name }
                                writeSavedPresets(context, savedPresets)
                                presetMessage = "Preset '${item.name}' removido."
                            }) { Text("Excluir") }
                        }
                    }
                }
            }

            else -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("CONTROLADORES MIDI", color = cyan, fontWeight = FontWeight.Bold)
                        Text(midiStatus, color = white)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { refreshMidiDevices() }, modifier = Modifier.weight(1f)) { Text("Procurar") }
                            OutlinedButton(onClick = { disconnectMidi() }, modifier = Modifier.weight(1f)) { Text("Desconectar todos") }
                        }
                        if (midiAvailable.isEmpty()) Text("Toque em Procurar para listar controladores USB MIDI.", color = muted, fontSize = 12.sp)
                        midiAvailable.forEach { info ->
                            val deviceName = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Controlador MIDI"
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(deviceName, color = white, modifier = Modifier.weight(1f))
                                Button(onClick = { connectMidi(info) }, enabled = !midiNames.contains(deviceName)) { Text(if (midiNames.contains(deviceName)) "Conectado" else "Conectar") }
                            }
                        }
                        Text("MAPEAMENTO MIDI CC", color = cyan, fontWeight = FontWeight.Bold)
                        Text("Informe os números CC (0–127) enviados pelo controlador.", color = muted, fontSize = 12.sp)
                        OutlinedTextField(value = ccMaster, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccMaster = it }, label = { Text("CC volume master") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccSustain, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccSustain = it }, label = { Text("CC sustain") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack1, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack1 = it }, label = { Text("CC volume faixa 1") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack2, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack2 = it }, label = { Text("CC volume faixa 2") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack3, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack3 = it }, label = { Text("CC volume faixa 3") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack4, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack4 = it }, label = { Text("CC volume faixa 4") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = ccTrack5, onValueChange = { if (it.isEmpty() || (it.length <= 3 && it.toIntOrNull() in 0..127)) ccTrack5 = it }, label = { Text("CC volume faixa 5") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text("Padrões: CC7 master, CC64 sustain, CC20–24 volumes das faixas. Todos os controladores conectados podem tocar as faixas.", color = muted, fontSize = 12.sp)
                        Text("Motor SF2: ${if (loaded) "carregado" else "não carregado"}", color = white)
                        Text(status, color = muted)
                    }
                }
            }
        }
    }
}

private fun readSavedPresets(context: Context): List<SavedPreset> {
    return try {
        val raw = context.getSharedPreferences("sf2_player", Context.MODE_PRIVATE).getString("presets", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); SavedPreset(o.getString("name"), o.getString("json")) }
    } catch (_: Exception) { emptyList() }
}

private fun writeSavedPresets(context: Context, presets: List<SavedPreset>) {
    val arr = JSONArray()
    presets.forEach { arr.put(JSONObject().put("name", it.name).put("json", it.json)) }
    context.getSharedPreferences("sf2_player", Context.MODE_PRIVATE).edit().putString("presets", arr.toString()).apply()
}
