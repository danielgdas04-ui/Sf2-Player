# SF2 Player v0.5

Projeto Android SF2 Player com seleção de timbres, teclado virtual, MIDI USB, presets salvos localmente, cinco faixas com seleção de instrumento e volume individual.

## Compilação

O workflow GitHub Actions é fornecido em `.github/workflows/build-apk.yml`. Envie o arquivo `SF2Player_v0.5_Presets_Multifaixas.zip` para a raiz do repositório e substitua o workflow pelo conteúdo do arquivo `build-apk.yml`.

O workflow baixa o cabeçalho TinySoundFont durante a compilação. A compilação remota e o teste em aparelho devem ser feitos no GitHub Actions/Android.
