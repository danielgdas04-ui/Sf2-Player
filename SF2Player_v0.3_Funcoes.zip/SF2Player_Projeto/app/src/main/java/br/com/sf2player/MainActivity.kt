package br.com.sf2player

import android.content.Context
import android.media.midi.*
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.io.File

private val bg=Color(0xFF0D1117); private val panel=Color(0xFF171F2B); private val cyan=Color(0xFF38BDF8); private val white=Color(0xFFF8FAFC); private val muted=Color(0xFF9CA3AF)
class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); window.statusBarColor=android.graphics.Color.rgb(13,17,23); setContent { MaterialTheme(colorScheme=darkColorScheme(primary=cyan,background=bg,surface=panel,onBackground=white,onSurface=white)){ PlayerScreen() } } } }

@Composable private fun PlayerScreen(){
 val context=androidx.compose.ui.platform.LocalContext.current
 val engine= remember { NativeSynth() }
 var sf2Name by remember { mutableStateOf("Nenhum SoundFont selecionado") }; var status by remember { mutableStateOf("Escolha um arquivo .sf2 para começar") }; var loaded by remember { mutableStateOf(false) }; var volume by remember { mutableFloatStateOf(0.8f) }; var octave by remember { mutableIntStateOf(0) }; var transpose by remember { mutableIntStateOf(0) }; var sustain by remember { mutableStateOf(false) }; var active by remember { mutableStateOf(setOf<Int>()) }; var tab by remember { mutableStateOf("Tocar") }; var midiStatus by remember { mutableStateOf("MIDI USB: desconectado") }; var midiDevice by remember { mutableStateOf<MidiDevice?>(null) }; var presets by remember { mutableStateOf(listOf<String>()) }; var preset by remember { mutableIntStateOf(0) }
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri:Uri? -> if(uri!=null){ status="Copiando SoundFont…"; sf2Name=uri.lastPathSegment?.substringAfterLast('/') ?: "SoundFont.sf2"; kotlinx.coroutines.MainScope().launch { try { val file=withContext(Dispatchers.IO){ val f=File(context.cacheDir,"active-soundfont.sf2"); context.contentResolver.openInputStream(uri).use { input -> requireNotNull(input){"Não foi possível abrir o arquivo"}.copyTo(f.outputStream()) }; f }; loaded=engine.load(file); status=engine.status; presets=if(loaded) (0 until engine.presetCount()).map { engine.presetName(it) } else emptyList(); preset=0 } catch(e:Exception){loaded=false;status="Erro: ${e.message}"} } } }
 DisposableEffect(Unit){ onDispose { try { midiDevice?.close() } catch (_:Exception) {}; engine.close() } }
 fun connectMidi() {
   try {
     val manager=context.getSystemService(Context.MIDI_SERVICE) as MidiManager
     val info=manager.devices.firstOrNull { it.outputPortCount>0 }
     if(info==null){midiStatus="Nenhum dispositivo MIDI com saída detectado";return}
     manager.openDevice(info,{ device ->
       if(device==null){midiStatus="Não foi possível abrir o dispositivo MIDI";return@openDevice}
       midiDevice=device
       val port=device.openOutputPort(0)
       if(port==null){midiStatus="Não foi possível abrir a saída MIDI";return@openDevice}
       port.connect(object:MidiReceiver(){ override fun onSend(msg:ByteArray, offset:Int, count:Int, timestamp:Long){ if(count<1)return; val s=msg[offset].toInt() and 0xFF; val type=s and 0xF0; val ch=s and 0x0F; if(count>=3){val a=msg[offset+1].toInt() and 0x7F; val b=msg[offset+2].toInt() and 0x7F; when(type){0x90->if(b==0)engine.noteOff(a) else engine.noteOn(a,b);0x80->engine.noteOff(a);0xB0->if(a==64)engine.setSustain(b>=64);0xC0->if(loaded&&a<128){val n=engine.presetCount();if(n>0)engine.selectPreset(b.coerceIn(0,n-1))}} } } })
       midiStatus="Conectado: ${info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI USB"}"
     },android.os.Handler(context.mainLooper))
   }catch(e:Exception){midiStatus="Erro MIDI: ${e.message}"}
 }
 Column(Modifier.fillMaxSize().background(bg).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
  Text("SF2 PLAYER",fontSize=24.sp,fontWeight=FontWeight.Black,color=white); Text("SoundFont player • versão 0.3",fontSize=13.sp,color=muted)
  Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf("Tocar","Instrumentos","MIDI / Diagnóstico").forEach{ FilterChip(selected=tab==it,onClick={tab=it},label={Text(it)}) } }
  when(tab){
   "Tocar" -> {
    Card(colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){ Text("SOUNDFONT",color=cyan,fontWeight=FontWeight.Bold); Text(sf2Name,color=white); Button(onClick={picker.launch(arrayOf("*/*"))},modifier=Modifier.fillMaxWidth()){Text("Abrir SoundFont (.sf2)")}; Text(status,color=if(loaded) Color(0xFF86EFAC) else Color(0xFFFBBF24),fontSize=12.sp) } }
    Card(colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("CONTROLES",color=cyan,fontWeight=FontWeight.Bold); Text("Volume ${(volume*100).toInt()}%",color=white); Slider(value=volume,onValueChange={volume=it;engine.setVolume(it)}); Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={octave=(octave-1).coerceAtLeast(-3)}){Text("− Oitava")}; Text("Oitava $octave",color=white); OutlinedButton(onClick={octave=(octave+1).coerceAtMost(3)}){Text("+ Oitava")}}; Row(verticalAlignment=Alignment.CenterVertically){Text("Transposição: $transpose",Modifier.weight(1f)); TextButton(onClick={transpose=(transpose-1).coerceAtLeast(-12)}){Text("−")}; TextButton(onClick={transpose=(transpose+1).coerceAtMost(12)}){Text("+")}}; Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=sustain,onCheckedChange={sustain=it;engine.setSustain(it)});Text("Sustain",color=muted,fontSize=12.sp)} } }
    Text("TECLADO • C2–C6",color=cyan,fontWeight=FontWeight.Bold)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(3.dp)){ (36..83).forEach{ key -> val isBlack=key%12 in listOf(1,3,6,8,10); val down=key in active; Surface(color=if(down) cyan else if(isBlack) Color(0xFF303846) else Color(0xFFE5E7EB),shape=RoundedCornerShape(5.dp),modifier=Modifier.width(if(isBlack) 35.dp else 42.dp).height(if(isBlack) 116.dp else 150.dp).pointerInput(key,octave,transpose,loaded){ awaitEachGesture { awaitFirstDown(); val note=key+octave*12+transpose; if(loaded && note in 0..127){engine.noteOn(note);active=active+key}; waitForUpOrCancellation(); if(loaded && note in 0..127){engine.noteOff(note);active=active-key} } }){ Box(Modifier.fillMaxSize().padding(bottom=8.dp),contentAlignment=Alignment.BottomCenter){Text(if(key%12==0) "C${key/12-1}" else "",color=if(isBlack&&!down) white else Color.DarkGray,fontSize=10.sp)} } } }
    Text("Pressione e segure uma tecla para tocar.",color=muted,fontSize=12.sp)
   }
   "Instrumentos" -> Card(colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("SELECIONAR INSTRUMENTO",color=cyan,fontWeight=FontWeight.Bold);if(!loaded)Text("Importe um SoundFont primeiro.",color=muted) else if(presets.isEmpty())Text("Este SF2 não contém presets legíveis.",color=muted) else {Text("Preset ${preset+1} de ${presets.size}",color=muted);Text(presets[preset],color=white);var expanded by remember { mutableStateOf(false) };ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}){OutlinedTextField(value=presets[preset],onValueChange={},readOnly=true,label={Text("Instrumento")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){presets.forEachIndexed{idx,name->DropdownMenuItem(text={Text(name)},onClick={preset=idx;engine.selectPreset(idx);expanded=false})}}};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={preset=(preset-1).coerceAtLeast(0);engine.selectPreset(preset)}){Text("Anterior")};OutlinedButton(onClick={preset=(preset+1).coerceAtMost(presets.lastIndex);engine.selectPreset(preset)}){Text("Próximo")}}}}}
   else -> Card(colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("MIDI USB / DIAGNÓSTICO",color=cyan,fontWeight=FontWeight.Bold);Text(midiStatus,color=white);Button(onClick={connectMidi()},modifier=Modifier.fillMaxWidth()){Text("Conectar teclado MIDI USB")};Text("Conecte o teclado ao celular com adaptador USB OTG e toque em Conectar.",color=muted,fontSize=12.sp);Text("Motor SF2: ${if(loaded) "carregado" else "não carregado"}",color=white);Text(status,color=muted)}}
  }
 }
}
