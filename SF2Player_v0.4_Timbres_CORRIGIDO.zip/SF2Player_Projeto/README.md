SF2 Player Android - versão corrigida para seleção de timbres.

A seleção de presets é aplicada ao canal MIDI 0, e a reprodução de notas usa as funções de canal do TinySoundFont para respeitar o timbre selecionado.

Compile usando o workflow .github/workflows/build-apk.yml no GitHub Actions.
