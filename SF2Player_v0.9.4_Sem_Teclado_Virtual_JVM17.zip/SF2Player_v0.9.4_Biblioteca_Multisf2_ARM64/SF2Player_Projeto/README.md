# SF2 Player 0.9.4 — Biblioteca multifaixa experimental

Esta versão acrescenta uma biblioteca privada e persistente de arquivos SoundFont (`.sf2`). Os arquivos importados são copiados para `filesDir/soundfonts/` e podem ser atribuídos individualmente a cinco faixas. Cada canal MIDI seleciona seu próprio SoundFont e programa dentro de uma única instância FluidSynth.

A interface da aba **Faixas** adapta-se à orientação: lista de canais na vertical do aparelho e canais em colunas lado a lado quando o aparelho está na horizontal.

## Limitações e validação

- Os arquivos SF2 são armazenados no formato original; não é necessária uma conversão de formato para FluidSynth.
- A biblioteca persiste entre reinicializações do aplicativo. Os presets guardam as referências aos arquivos importados.
- Esta entrega é uma alteração de código-fonte. A compilação e a reprodução real precisam ser verificadas no GitHub Actions e em um dispositivo Android físico.
- FluidSynth é distribuído sob LGPL-2.1-or-later; preserve os avisos de licença ao redistribuir o aplicativo.


## Alteração da interface
- Removido o teclado musical virtual da tela “Tocar”. A entrada de notas permanece destinada a controladores MIDI externos compatíveis.
